"""Gera cenários de teste no mesmo formato dos CSVs originais.
Assume 5 dias (Seg..Sex) x 5 períodos/dia = 25 slots por semana."""
import csv, os, random
DIAS = ["Seg", "Ter", "Qua", "Qui", "Sex"]
PERIODOS = 5
OUT = "cenarios"

def w(pasta, nome, header, rows):
    os.makedirs(pasta, exist_ok=True)
    with open(os.path.join(pasta, nome), "w", newline="", encoding="utf-8") as f:
        c = csv.writer(f, lineterminator="\n"); c.writerow(header); c.writerows(rows)

def bloquear(prof, dias=DIAS, periodos=range(1, PERIODOS + 1)):
    return [(prof, d, p) for d in dias for p in periodos]

def salvar(nome, turmas, disc, salas, exc):
    p = os.path.join(OUT, nome)
    w(p, "turmas.csv", ["turma"], [(t,) for t in turmas])
    w(p, "disciplinas.csv", ["disciplina","professor","carga_semanal","duplo_periodo","sala_especial"], disc)
    w(p, "salas.csv", ["sala","tipo","quantidade"], salas)
    w(p, "disponibilidade_excecoes.csv", ["professor","dia","periodo"], exc)

def turmas(ano, n): return [f"{ano}º{chr(65+i)}" for i in range(n)]

SALAS_PADRAO = lambda n: [("Sala Normal","normal",n),("Laboratório","especial",1),("Ginásio","especial",1)]

# 1) Básico: igual ao original mas com 3 turmas e outros professores
salvar("01_basico", turmas(8,3),
  [("Matemática","Prof. Marta",4,"nao",""),("Português","Prof. Nuno",4,"nao",""),
   ("Ciências","Prof. Olga",3,"nao","Laboratório"),("Geografia","Prof. Paulo",2,"nao",""),
   ("Inglês","Prof. Paulo",2,"nao",""),("Educação Física","Prof. Rui",2,"sim","Ginásio")],
  SALAS_PADRAO(6), bloquear("Prof. Rui", periodos=[1,2]))

# 2) Médio: 6 turmas, professores com várias disciplinas, laboratório duplo
disc = [("Matemática","Prof. Marta",4,"nao",""),("Português","Prof. Nuno",4,"nao",""),
  ("Física","Prof. Sofia",2,"sim","Laboratório"),("Química","Prof. Sofia",2,"sim","Laboratório"),
  ("Biologia","Prof. Tiago",2,"nao",""),("História","Prof. Ursula",2,"nao",""),
  ("Geografia","Prof. Ursula",2,"nao",""),("Inglês","Prof. Vasco",3,"nao",""),
  ("Educação Física","Prof. Rui",2,"sim","Ginásio"),("Artes","Prof. Zélia",1,"nao","")]
exc = bloquear("Prof. Rui", periodos=[1,2]) + bloquear("Prof. Vasco", dias=["Qua"]) + bloquear("Prof. Zélia", dias=["Seg","Ter"])
salvar("02_medio", turmas(9,6), disc, SALAS_PADRAO(8), exc)

# 3) Grande: 8 turmas, 2 laboratórios, 2 ginásios, exceções aleatórias (seed fixa)
random.seed(42)
disc = [("Matemática","Prof. Marta",2,"nao",""),("Português","Prof. Nuno",2,"nao",""),
  ("Ciências","Prof. Olga",2,"nao","Laboratório"),("Física","Prof. Hugo",2,"sim","Laboratório"),
  ("Inglês","Prof. Vasco",2,"nao",""),("História","Prof. Ursula",2,"nao",""),
  ("Geografia","Prof. Ursula",1,"nao",""),("Educação Física","Prof. Rui",2,"sim","Ginásio"),
  ("Música","Prof. Zélia",1,"nao",""),("Artes","Prof. Zélia",1,"nao","")]
exc = bloquear("Prof. Rui", periodos=[1])
for prof in ["Prof. Marta","Prof. Nuno","Prof. Olga","Prof. Hugo","Prof. Vasco"]:
    exc += [(prof, random.choice(DIAS), p) for p in random.sample(range(1, PERIODOS+1), 2)]
exc = sorted(set(exc))
salvar("03_grande", turmas(7,8), disc,
  [("Sala Normal","normal",8),("Laboratório","especial",2),("Ginásio","especial",2)], exc)

# 4) INVIÁVEL (só por causa do laboratório): 10 turmas x (2h+2h) = 40h > 25 slots de 1 lab
salvar("04_inviavel_laboratorio", turmas(9,10),
  [("Matemática","Prof. Marta",2,"nao",""),("Ciências","Prof. Olga",2,"nao","Laboratório"),
   ("Física","Prof. Hugo",2,"nao","Laboratório")],
  SALAS_PADRAO(10), [])

# 5) INVIÁVEL: professor sobrecarregado (4 turmas x 4h = 16h, mas só 10 slots livres)
salvar("05_inviavel_professor", turmas(7,4),
  [("Matemática","Prof. Marta",4,"nao",""),("Português","Prof. Nuno",4,"nao","")],
  SALAS_PADRAO(4), bloquear("Prof. Marta", dias=["Seg","Ter","Qua"]) + bloquear("Prof. Marta", dias=["Qui"], periodos=[1,2,3,4]))

# 6) Casos-limite: sem exceções, duplo em disciplina normal, carga 1, carga ímpar com duplo,
#    uma turma só, professor com nome com acento/hífen, sala especial com nome diferente
salvar("06_casos_limite", ["10ºÚnica"],
  [("Matemática","Prof. João-Pedro",6,"nao",""),("Informática","Prof. Inês",2,"sim","Sala TIC"),
   ("Filosofia","Prof. Inês",3,"sim",""),("Artes","Prof. Zélia",1,"nao","")],
  [("Sala Normal","normal",1),("Sala TIC","especial",1)], [])

# 7) Apertado mas viável: turma com carga total = 25 (todos os slots ocupados)
salvar("07_turma_lotada", turmas(9,2),
  [("Matemática","Prof. Marta",5,"nao",""),("Português","Prof. Nuno",5,"nao",""),
   ("Ciências","Prof. Olga",5,"nao","Laboratório"),("Inglês","Prof. Vasco",5,"nao",""),
   ("Educação Física","Prof. Rui",5,"sim","Ginásio")],
  [("Sala Normal","normal",2),("Laboratório","especial",1),("Ginásio","especial",1)], [])

# 8) Exceção referenciando professor inexistente e período fora do intervalo (teste de validação)
salvar("08_dados_invalidos", turmas(7,2),
  [("Matemática","Prof. Marta",4,"nao",""),("Ciências","Prof. Olga",3,"nao","Laboratório")],
  SALAS_PADRAO(4), [("Prof. Fantasma","Seg",1),("Prof. Marta","Dom",1),("Prof. Marta","Seg",9)])
